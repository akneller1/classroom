/** Independent post-install validation, before any GitHub push. */
import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
const pkg=path.dirname(fileURLToPath(import.meta.url));
const [faArg,clArg]=process.argv.slice(2);assert(faArg&&clArg,'Usage: node verify-phase2.mjs <FinancialAlgebra checkout> <classroom checkout>');
const fa=path.resolve(faArg),cl=path.resolve(clArg);
let count=0,groups={};const seen=new Set();
for(const name of fs.readdirSync(path.join(pkg,'patches/math1')).filter(n=>n.endsWith('.json'))){
 const edits=JSON.parse(fs.readFileSync(path.join(pkg,'patches/math1',name))).edits;
 for(const e of edits){
  assert(!seen.has(e.id),`Duplicate ${e.id}`);seen.add(e.id);
  const bank=JSON.parse(fs.readFileSync(path.join(fa,e.bank)));
  const q=bank.questions.find(q=>q.id===e.id);
  assert(q,`Missing question ${e.id}`);
  const d=e.changes.diagram.to;
  assert.deepEqual(q.diagram,d,`Different Grade 1 picture reference: ${e.id}`);
  assert(q.sourceNotes.includes(e.changes.sourceNotes.append),`Missing provenance for ${e.id}`);
  const png=fs.readFileSync(path.join(fa,d.spec.src));
  assert(png.length>100&&png.subarray(0,8).equals(Buffer.from('89504e470d0a1a0a','hex')),`Invalid PNG for ${e.id}`);
  assert(d.spec.alt&&d.spec.alt.length>5,`No alt text for ${e.id}`);
  const g=e.bank.split('/')[2].replace('.json','');groups[g]=(groups[g]||0)+1;count++;
 }
}
assert.equal(count,412);
let svgCount=0;
const walk=(from,rel='')=>{for(const ent of fs.readdirSync(from,{withFileTypes:true})){
 const r=path.join(rel,ent.name),src=path.join(from,ent.name);
 if(ent.isDirectory())walk(src,r);else if(ent.name.endsWith('.svg')){
 const dest=path.join(cl,'worksheet-generator/core/elementary/art',r);
 assert(fs.existsSync(dest),`Missing art: ${r}`);
 const t=fs.readFileSync(dest,'utf8');assert(t.includes('<svg')&&t.includes('<title>'),`SVG not accessible: ${r}`);svgCount++;
 }
}};
walk(path.join(pkg,'art'));assert.equal(svgCount,54);
const css=fs.readFileSync(path.join(cl,'worksheet-generator/core/elementary/elementary-print.css'),'utf8');
const js=fs.readFileSync(path.join(cl,'worksheet-generator/menu/elementary-print.js'),'utf8');
const test=fs.readFileSync(path.join(cl,'scripts/test-elementary-print-browser.cjs'),'utf8');
assert(css.includes('max-height:2.1in!important')&&css.includes('.el-figrow'),'Missing Phase 2 CSS');
assert(js.includes('E.unitBadge=function(cfg)')&&js.includes(',sidePicture='),'Missing banner or answer layout');
assert(test.includes('(grade<3?2.1:1.1)'),'Browser test needs 2.1in primary cap');
console.log('PASS: '+count+' exact source pictures with accessible PNG + alt text; '+svgCount+' original SVG art; primary print layout patched.');
console.log('Six Grade 1 units:',JSON.stringify(groups));
