# PowerShell (Windows): apply, check, commit, and publish the reviewed Phase 2 update.
# Example: .\deploy-phase2.ps1 -FinancialAlgebra 'C:\GitHub\FinancialAlgebra' -Classroom 'C:\GitHub\classroom' -Publish
param(
  [Parameter(Mandatory=$true)][string]$FinancialAlgebra,
  [Parameter(Mandatory=$true)][string]$Classroom,
  [switch]$Publish
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
function Run([string]$exe,[string[]]$argv){
  & $exe @argv
  if ($LASTEXITCODE -ne 0) { throw "$exe failed with exit code $LASTEXITCODE" }
}
$FA=(Resolve-Path $FinancialAlgebra).Path
$CL=(Resolve-Path $Classroom).Path
$Here=$PSScriptRoot
if (-not (Test-Path (Join-Path $FA 'question-banks\math1\word-problems-20.json'))) { throw 'FinancialAlgebra path is not the expected repository.' }
if (-not (Test-Path (Join-Path $CL '.github\workflows\deploy-site.yml'))) { throw 'Classroom path is not the expected repository.' }
if ($Publish) {
  foreach ($r in @($FA,$CL)) {
    if ((& git -C $r branch --show-current).Trim() -ne 'main') { throw "Checkout must be on main: $r" }
    if ((& git -C $r status --porcelain | Out-String).Trim()) { throw "Uncommitted changes; please commit or stash first: $r" }
    Run 'git' @('-C',$r,'pull','--ff-only','origin','main')
  }
}
Run 'node' @((Join-Path $Here 'install-phase2.mjs'),$FA,$CL)
Run 'node' @((Join-Path $Here 'verify-phase2.mjs'),$FA,$CL)
if (-not $Publish) {
  Write-Host 'Phase 2 is installed and verified locally, but NOT pushed. Commit FinancialAlgebra first, run pin-grade1.mjs, then commit Classroom.'
  exit 0
}
Run 'git' @('-C',$FA,'add','question-banks/math1','question-banks/assets/math1')
Run 'git' @('-C',$FA,'commit','-m','Add 412 checked Grade 1 story pictures')
Run 'git' @('-C',$FA,'push','origin','main')
Run 'node' @((Join-Path $Here 'pin-grade1.mjs'),$FA,$CL)
Run 'git' @('-C',$CL,'add','.github/workflows/deploy-site.yml','worksheet-generator/core/elementary/elementary-print.css','worksheet-generator/core/elementary/art','worksheet-generator/menu/elementary-print.js','scripts/test-elementary-print-browser.cjs')
Run 'git' @('-C',$CL,'commit','-m','Integrate kid-friendly Phase 2 art and illustrated print layouts')
Run 'git' @('-C',$CL,'push','origin','main')
Write-Host 'Both repositories pushed. GitHub Actions will build and deploy the Classroom site; check Deploy site workflow for final status.'
