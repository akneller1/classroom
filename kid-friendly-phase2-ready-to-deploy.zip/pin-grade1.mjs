// Run after committing and pushing FinancialAlgebra; pins its exact HEAD in Classroom Pages.
import fs from 'node:fs'; import path from 'node:path'; import {execFileSync} from 'node:child_process';
const [faArg,clArg]=process.argv.slice(2);
if(!faArg||!clArg)throw Error('Usage: node pin-grade1.mjs <FinancialAlgebra checkout> <classroom checkout>');
const fa=path.resolve(faArg),cl=path.resolve(clArg);
const sha=execFileSync('git',['-C',fa,'rev-parse','HEAD'],{encoding:'utf8'}).trim();
if(!/^[a-f0-9]{40}$/.test(sha))throw Error('Bad source SHA');
const dirty=execFileSync('git',['-C',fa,'status','--porcelain'],{encoding:'utf8'}).trim();
if(dirty)throw Error('FinancialAlgebra still has uncommitted changes; commit first.');
const workflow=path.join(cl,'.github/workflows/deploy-site.yml');let y=fs.readFileSync(workflow,'utf8');
const section=/(- name: Check out validated Grade 1 source from FinancialAlgebra\s+uses: actions\/checkout@v4\s+with:\s+repository: akneller1\/FinancialAlgebra\s+ref: )[a-f0-9]{40}/;
if(!section.test(y))throw Error('Could not locate Grade 1 workflow pin');
y=y.replace(section,'$1'+sha);fs.writeFileSync(workflow,y);
console.log('Pinned production Grade 1 source to '+sha+'. Commit and push Classroom to deploy.');
