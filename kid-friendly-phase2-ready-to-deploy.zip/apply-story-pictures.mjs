// Apply story-picture patches to a FinancialAlgebra checkout.
// usage: node apply-story-pictures.mjs <FinancialAlgebra folder> [package folder, default: this file's folder]
// For each edit: the question must exist and have NO diagram yet (otherwise the script stops and changes nothing).
// Copies each PNG into question-banks/assets/<course>/<unit>/ and sets `diagram`; appends a note to sourceNotes.
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const fa = path.resolve(process.argv[2] || '.');
const pkg = path.resolve(process.argv[3] || path.dirname(fileURLToPath(import.meta.url)));
const read = p => JSON.parse(fs.readFileSync(p, 'utf8'));
const patchDir = path.join(pkg, 'patches');
const plans = [];
for (const course of fs.readdirSync(patchDir)) for (const name of fs.readdirSync(path.join(patchDir, course))) {
  const { edits } = read(path.join(patchDir, course, name));
  for (const e of edits) plans.push(e);
}
// 1. check everything first
const banks = new Map();
for (const e of plans) {
  const file = path.join(fa, e.bank);
  if (!banks.has(file)) banks.set(file, read(file));
  const q = banks.get(file).questions.find(x => x.id === e.id);
  if (!q) throw Error('Missing question ' + e.id + ' in ' + e.bank);
  if (q.diagram) throw Error('Question already has a diagram, not overwriting: ' + e.id);
  const src = e.changes.diagram.to.spec.src;
  if (!fs.existsSync(path.join(pkg, 'assets', src))) throw Error('Missing picture ' + src);
  if (fs.existsSync(path.join(fa, src))) throw Error('Picture already exists, not overwriting: ' + src);
}
// 2. apply
for (const e of plans) {
  const file = path.join(fa, e.bank), q = banks.get(file).questions.find(x => x.id === e.id);
  q.diagram = e.changes.diagram.to;
  if (e.changes.sourceNotes?.append && !String(q.sourceNotes || '').includes(e.changes.sourceNotes.append)) q.sourceNotes = (q.sourceNotes || '') + e.changes.sourceNotes.append;
  const src = q.diagram.spec.src, dest = path.join(fa, src);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(path.join(pkg, 'assets', src), dest);
}
for (const [file, bank] of banks) fs.writeFileSync(file, JSON.stringify(bank, null, 1));
console.log(`Story pictures applied: ${plans.length} questions in ${banks.size} bank files.`);
