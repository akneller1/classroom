"""Independent check of a story picture. Shares no code with stories.py or scenes.py.

check(prompt, kind, svg, answer, fmt, options) -> list of problems (empty = pass).
It reads the integers in the story text, counts what the SVG actually draws (objects, crossed-out objects, empty
slots), and requires (1) the drawing to match the story numbers for that picture type and (2) the bank's own answer to
agree with the number the story asks for.
"""
import re


def story_text(prompt):
    p = prompt.replace("−", "-")
    lines = [l for l in p.split("\n") if l.strip()]
    if lines and re.search(r"solved this problem\.$", lines[0]):
        lines = [l for l in lines[1:] if not re.search(r"answered:|^Find the mistake", l)]
    p = " ".join(lines)
    p = re.sub(r"^True or false\?\s*", "", p)
    p = re.sub(r"\s*Answer shown:.*$", "", p)
    return p


def story_ints(prompt):
    return [int(n) for n in re.findall(r"\d+", story_text(prompt))]


def counts(svg):
    return (len(re.findall(r'class="o"', svg)), len(re.findall(r'class="x"', svg)), len(re.findall(r'class="s"', svg)))


def expected(kind, n):
    """-> (objects drawn, crossed, slots, asked-for number or None) from the story integers alone."""
    if kind == "add": return n[0] + n[1], 0, 0, n[0] + n[1]
    if kind == "take" and len(n) == 2 and "had some" not in KIND_CTX[0]: return n[0], n[1], 0, n[0] - n[1]
    if kind == "take": return n[0] + n[1], n[0], 0, n[0] + n[1]                      # had some, gave B away, has C left
    if kind == "add_start": return n[0], 0, 0, n[1] - n[0]
    if kind == "group": return n[0], 0, 0, n[0] - n[1]
    if kind == "fill":
        lo, hi = sorted(n[:2])
        return lo, 0, hi - lo, hi - lo
    if kind == "hidden": return n[1], 0, 0, n[0] - n[1]
    if kind == "colors": return n[0] + n[1], 0, 0, n[0] + n[1]
    if kind == "colors_rest": return n[0], 0, 0, n[0] - sum(n[1:])
    if kind == "mixed": return sum(n), 0, 0, sum(n)
    if kind == "compare":
        if len(n) == 3: return sum(n), 0, 0, n[0] + n[1] - n[2]
        return n[0] + n[1], 0, 0, abs(n[0] - n[1])
    if kind == "compare_diff":
        a, d = n[0], n[1]
        more = re.search(r"\d+ more [a-z]+ than", story_text(KIND_CTX[0])) is not None
        return (a + a + d, 0, 0, a + d) if more else (a + a - d, 0, d, a - d)
    raise ValueError(kind)


KIND_CTX = [""]


def answer_ok(want, answer, fmt):
    a = answer if isinstance(answer, str) else " ".join(map(str, answer)) if isinstance(answer, list) else str(answer)
    a = a.replace("−", "-")
    nums = [int(x) for x in re.findall(r"\d+", a)]
    if fmt == "short-answer": return bool(nums) and nums[0] == want
    if re.match(r"^(True|False)\b", a): return want in nums
    if "___" in a and "=" in a:                       # an equation with a blank: put the asked-for number in and test it
        try:
            l, r = a.replace("___", str(want)).split("=")
            return eval(l.replace("×", "*")) == eval(r.replace("×", "*"))
        except Exception: return False
    if re.match(r"^(True|False)\b", a): return want in nums
    if re.search(r"[+-]", a) and "=" not in a: return False
    return want in nums


def check(prompt, kind, svg, answer, fmt):
    KIND_CTX[0] = prompt
    n = story_ints(prompt)
    probs = []
    try: eo, ex, es, want = expected(kind, n)
    except Exception as e: return [f"cannot derive expected counts: {e}"]
    o, x, s = counts(svg)
    if (o, x, s) != (eo, ex, es): probs.append(f"drawn objects/crossed/slots {(o, x, s)} != expected {(eo, ex, es)} from story numbers {n}")
    if o > 40: probs.append("too many objects")
    if want is not None and want < 0: probs.append("negative result")
    asks_who = re.search(r"Who has (more|fewer)", prompt)
    asks_op = re.search(r"Should you add or subtract", prompt)
    if asks_op:
        word = "Subtract" if kind in ("take", "group") else "Add"
        if not str(answer).startswith(word): probs.append(f"add/subtract answer {answer!r} does not fit a {kind} picture")
    elif not asks_who and not answer_ok(want, answer, fmt): probs.append(f"bank answer {answer!r} does not match the story's number {want}")
    if asks_who:
        names = re.findall(r"\b([A-Z][a-z]+) has \d+", prompt)
        if not any(nm in str(answer) for nm in names): probs.append("who-has-more answer names nobody in the story")
    return probs
