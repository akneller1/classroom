"""Grade mascots (Grades 1-5) and Grade 1 unit badges. Original characters, site palette, 120 x 120 viewBox."""
import os, sys
OUT = sys.argv[1]
INK = "#14173a"
S = f'stroke="{INK}" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"'
s = f'stroke="{INK}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"'
FONT = 'font-family="Atkinson Hyperlegible, DejaVu Sans, Arial, sans-serif" font-weight="700"'


def wrap(body, title, vb=120):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {vb} {vb}" width="{vb}" height="{vb}" role="img" '
            f'aria-label="{title}"><title>{title}</title>{body}</svg>')


def face(cx, cy, k=1.0, mouth="smile"):
    e = f'<circle cx="{cx - 11 * k}" cy="{cy}" r="{4.2 * k}" fill="{INK}"/><circle cx="{cx + 11 * k}" cy="{cy}" r="{4.2 * k}" fill="{INK}"/>'
    e += f'<circle cx="{cx - 9.6 * k}" cy="{cy - 1.4 * k}" r="{1.3 * k}" fill="#fff"/><circle cx="{cx + 12.4 * k}" cy="{cy - 1.4 * k}" r="{1.3 * k}" fill="#fff"/>'
    e += f'<path d="M{cx - 9 * k} {cy + 10 * k}c5 6 13 6 18 0" fill="none" {s}/>'
    e += f'<ellipse cx="{cx - 19 * k}" cy="{cy + 8 * k}" rx="{4.5 * k}" ry="{3 * k}" fill="#ff9fb3" opacity=".8"/><ellipse cx="{cx + 19 * k}" cy="{cy + 8 * k}" rx="{4.5 * k}" ry="{3 * k}" fill="#ff9fb3" opacity=".8"/>'
    return e


def arms(lx, ly, rx, ry, up=True):
    d = -14 if up else 10
    return (f'<path d="M{lx} {ly}c-8 {d / 2} -14 {d} -16 {d}" fill="none" {S}/><circle cx="{lx - 17}" cy="{ly + d}" r="5" fill="#fff" {s}/>'
            f'<path d="M{rx} {ry}c8 {d / 2} 14 {d} 16 {d}" fill="none" {S}/><circle cx="{rx + 17}" cy="{ry + d}" r="5" fill="#fff" {s}/>')


def legs(x1, x2, y):
    return (f'<path d="M{x1} {y}v10" {S}/><path d="M{x2} {y}v10" {S}/>'
            f'<ellipse cx="{x1 - 3}" cy="{y + 12}" rx="7" ry="4" fill="{INK}"/><ellipse cx="{x2 + 3}" cy="{y + 12}" rx="7" ry="4" fill="{INK}"/>')


MASCOTS = {
 # Grade 1: Dot, a counting counter
 "grade1-dot": ("Dot, the Grade 1 counting counter",
     legs(50, 70, 92) + arms(28, 62, 92, 62) + f'<circle cx="60" cy="58" r="36" fill="#ff8a1f" {S}/>'
     '<circle cx="60" cy="58" r="27" fill="none" stroke="#ffffff" stroke-width="3" opacity=".55"/>' + face(60, 54)),
 # Grade 2: Cubie, a connecting cube
 "grade2-cubie": ("Cubie, the Grade 2 connecting cube",
     legs(48, 72, 96) + arms(26, 66, 94, 66) +
     f'<path d="M26 40l34-14 34 14v42l-34 14-34-14z" fill="#22c08a" {S}/><path d="M26 40l34 14 34-14M60 54v42" fill="none" {S}/>'
     f'<path d="M60 54l34-14v42l-34 14z" fill="#000" opacity=".12"/><ellipse cx="60" cy="31" rx="11" ry="5" fill="#9ff0d0" {s}/>' + face(43, 62, .7)),
 # Grade 3: Hexie, a pattern-block hexagon
 "grade3-hexie": ("Hexie, the Grade 3 hexagon",
     legs(48, 72, 96) + arms(24, 62, 96, 62) +
     f'<path d="M40 24h40l20 34-20 34H40L20 58z" fill="#ffd23f" {S}/><path d="M40 24l20 34 20-34M20 58h80M40 92l20-34 20 34" fill="none" stroke="#e0a800" stroke-width="2"/>'
     f'<path d="M40 24h40l20 34-20 34H40L20 58z" fill="none" {S}/>' + f'<circle cx="60" cy="56" r="20" fill="#fff4cc" opacity=".9"/>' + face(60, 54, .85)),
 # Grade 4: Zoom, a rocket
 "grade4-zoom": ("Zoom, the Grade 4 rocket",
     f'<path d="M48 92c2 10 6 16 12 22 6-6 10-12 12-22z" fill="#ff8a1f" {s}/><path d="M53 92c1 6 4 10 7 14 3-4 6-8 7-14z" fill="#ffd23f"/>'
     f'<path d="M40 70l-14 18 18-4zM80 70l14 18-18-4z" fill="#7448ff" {S}/>'
     f'<path d="M60 8c18 12 24 34 20 60l-4 24H44l-4-24c-4-26 2-48 20-60z" fill="#3547f5" {S}/>'
     f'<path d="M52 14c-6 8-9 18-9 28" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".5"/>'
     f'<circle cx="60" cy="50" r="17" fill="#e2e6ff" {S}/>' + face(60, 48, .65)),
 # Grade 5: Bit, a robot
 "grade5-bit": ("Bit, the Grade 5 robot",
     legs(48, 72, 100) + arms(28, 76, 92, 76, up=False) +
     f'<path d="M60 12v12" {S}/><circle cx="60" cy="10" r="5" fill="#ffd23f" {s}/>'
     f'<rect x="30" y="24" width="60" height="44" rx="12" fill="#7448ff" {S}/><rect x="38" y="32" width="44" height="28" rx="8" fill="#ebe3ff" {s}/>'
     f'<rect x="38" y="70" width="44" height="30" rx="8" fill="#9aa3d6" {S}/><circle cx="50" cy="85" r="4" fill="#22c08a"/><circle cx="62" cy="85" r="4" fill="#ff8a1f"/><circle cx="74" cy="85" r="4" fill="#3547f5"/>'
     + face(60, 44, .6)),
}


def badge(inner, color):
    return f'<circle cx="60" cy="60" r="54" fill="{color}" {S}/><circle cx="60" cy="60" r="44" fill="#ffffff" stroke="{INK}" stroke-width="2.5"/>{inner}'


def dot(cx, cy, col="#ff8a1f", r=7, crossed=False):
    o = f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{col}" {s}/>'
    if crossed: o += f'<path d="M{cx - r} {cy - r}L{cx + r} {cy + r}M{cx - r} {cy + r}L{cx + r} {cy - r}" {s}/>'
    return o


def tenframe(x, y, n, w=14, col="#ff8a1f", red=0):
    o = ""
    for i in range(10):
        r, c = divmod(i, 5)
        o += f'<rect x="{x + c * w}" y="{y + r * w}" width="{w}" height="{w}" fill="#fff" stroke="{INK}" stroke-width="2"/>'
        if i < n: o += dot(x + c * w + w / 2, y + r * w + w / 2, "#e2563b" if i < red else col, w / 2 - 2.5)
    return o


def text(x, y, t, size=20, col=INK):
    return f'<text x="{x}" y="{y}" text-anchor="middle" {FONT} font-size="{size}" fill="{col}">{t}</text>'


UNITS = {
 "count-120": ("Counting and Numbers to 120", "#ff8a1f", text(60, 52, "1 2 3", 20) + dot(40, 72) + dot(60, 72) + dot(80, 72)),
 "add-subtract-10": ("Addition and Subtraction within 10", "#3547f5", tenframe(25, 46, 7, 14, "#ffd23f", 4)),
 "add-subtract-20": ("Addition and Subtraction within 20", "#22c08a", tenframe(25, 30, 10, 14, "#e2563b") + tenframe(25, 62, 3, 14, "#ffd23f")),
 "equal-sign": ("The Equal Sign and Missing Numbers", "#7448ff",
     f'<path d="M60 36v40M36 44h48" {S}/><path d="M60 80l-10 6h20z" fill="{INK}"/>'
     f'<path d="M28 44l-8 18h16zM92 44l-8 18h16z" fill="#ebe3ff" {s}/>' + dot(28, 58, "#ff8a1f", 5) + dot(92, 58, "#ff8a1f", 5)
     ),
 "word-problems-20": ("Word Problems within 20", "#ff8a1f",
     f'<path d="M26 34h68a6 6 0 0 1 6 6v30a6 6 0 0 1-6 6H54l-14 12V76H26a6 6 0 0 1-6-6V40a6 6 0 0 1 6-6z" fill="#fff4e0" {s}/>'
     + dot(40, 55, "#e2563b") + dot(56, 55, "#e2563b") + text(72, 62, "+", 20) + dot(86, 55, "#ffd23f")),
 "tens-ones": ("Tens and Ones", "#3547f5",
     "".join(f'<rect x="{30 + i * 9}" y="32" width="7" height="50" rx="2" fill="#ffd23f" {s}/>' for i in range(3))
     + "".join(f'<path d="M30 {34 + j * 10}h25" stroke="{INK}" stroke-width="1.4"/>' for j in range(5))
     + dot(76, 48, "#ffd23f", 6) + dot(90, 48, "#ffd23f", 6) + dot(76, 64, "#ffd23f", 6) + text(60, 97, "30 + 3", 13)),
 "compare-numbers": ("Comparing Two-Digit Numbers", "#22c08a",
     "".join(f'<rect x="28" y="{80 - i * 9}" width="18" height="8" rx="2" fill="#3547f5" {s}/>' for i in range(5))
     + "".join(f'<rect x="74" y="{80 - i * 9}" width="18" height="8" rx="2" fill="#3547f5" {s}/>' for i in range(3))
     + text(60, 72, "&gt;", 26)),
 "add-subtract-100": ("Adding and Subtracting within 100", "#7448ff",
     "".join(f'<rect x="{30 + c * 12}" y="{26 + r * 12}" width="12" height="12" fill="{"#ebe3ff" if (r * 5 + c) % 6 else "#ffd23f"}" stroke="{INK}" stroke-width="1.6"/>' for r in range(5) for c in range(5))
     + text(60, 97, "100", 13)),
 "measuring-length": ("Measuring Length", "#ff8a1f",
     f'<rect x="22" y="62" width="76" height="18" rx="3" fill="#ffd23f" {s}/>'
     + "".join(f'<path d="M{28 + i * 8} 62v{8 if i % 2 else 12}" stroke="{INK}" stroke-width="2"/>' for i in range(9))
     + f'<g transform="rotate(-20 60 44)"><rect x="30" y="38" width="50" height="10" fill="#22c08a" {s}/><path d="M80 38l12 5-12 5z" fill="#ffe8d0" {s}/></g>'),
 "telling-time": ("Telling Time", "#3547f5",
     f'<circle cx="60" cy="60" r="32" fill="#fff" {S}/>' + "".join(f'<circle cx="{60 + 25 * c:.1f}" cy="{60 + 25 * s_:.1f}" r="2.4" fill="{INK}"/>'
     for c, s_ in ((0, -1), (1, 0), (0, 1), (-1, 0), (.5, -.866), (.866, -.5), (.866, .5), (.5, .866), (-.5, .866), (-.866, .5), (-.866, -.5), (-.5, -.866)))
     + f'<path d="M60 60V38M60 60l14 8" {S}/><circle cx="60" cy="60" r="4" fill="{INK}"/>'),
 "data": ("Organizing and Reading Data", "#22c08a",
     f'<path d="M30 30v56h62" fill="none" {S}/>' + f'<rect x="38" y="58" width="12" height="28" fill="#ff8a1f" {s}/>'
     f'<rect x="56" y="40" width="12" height="46" fill="#3547f5" {s}/><rect x="74" y="66" width="12" height="20" fill="#ffd23f" {s}/>'),
 "shapes-equal-shares": ("Shapes and Equal Shares", "#7448ff",
     f'<circle cx="44" cy="52" r="18" fill="#ffd23f" {s}/><path d="M44 34v36M26 52h36" {s}/>'
     f'<path d="M78 34l18 30H60z" fill="#ff8a1f" {s}/><rect x="36" y="74" width="20" height="16" fill="#3547f5" {s}/><rect x="66" y="72" width="22" height="20" rx="2" fill="#22c08a" {s}/>'),
}

os.makedirs(os.path.join(OUT, "mascots"), exist_ok=True); os.makedirs(os.path.join(OUT, "unit-badges", "grade1"), exist_ok=True)
for k, (t, body) in MASCOTS.items(): open(os.path.join(OUT, "mascots", k + ".svg"), "w").write(wrap(body, t))
for k, (t, col, inner) in UNITS.items(): open(os.path.join(OUT, "unit-badges", "grade1", k + ".svg"), "w").write(wrap(badge(inner, col), t + " unit badge"))
print(len(MASCOTS), "mascots,", len(UNITS), "grade 1 badges")
