"""Parse Grade 1-2 story problems into a picture spec.

parse(prompt) -> dict | None. The spec says what to draw and holds every count used, plus `result`: the number the
story asks for (or None when the question is not numeric, e.g. "Who has more?"). Only stories whose objects are in the
object library, and whose groups have 20 or fewer objects, get a spec.
"""
import re
from objects import lookup

NAME = r"(?:[A-Z][a-z]+)"
SUBJ = rf"(?:{NAME}|She|He|They|You)"
COLORS = "red|blue|green|yellow|orange|purple|pink|brown|white|black"
MAX_GROUP, MAX_TOTAL = 20, 24


def story_part(p):
    """Strip error-analysis and true/false wrappers; return the story text only."""
    p = p.replace("−", "-")
    lines = [l.strip() for l in p.split("\n") if l.strip()]
    if lines and re.match(rf"^{NAME} solved this problem\.$", lines[0]):
        lines = lines[1:]
        lines = [l for l in lines if not re.match(rf"^{NAME} answered:", l) and not l.startswith("Find the mistake")]
    p = " ".join(lines)
    p = re.sub(r"^True or false\?\s*", "", p)
    p = re.sub(r"\s*Answer shown:.*$", "", p)
    return p.strip()


def obj(noun):
    return lookup(noun) if noun else None


def ok(*ns):
    return all(0 <= n <= MAX_GROUP for n in ns) and sum(ns) <= MAX_TOTAL


def parse(prompt):
    p = story_part(prompt)
    for f in (f_rest_of_total, f_compare_colored, f_cup_box, f_start_unknown, f_some_left, f_boxes, f_days, f_three_colors, f_two_colors, f_two_colors_bag, f_hidden, f_fill, f_change_unknown, f_start_some_taken, f_compare_more_fewer,
              f_compare, f_pets, f_add, f_take):
        s = f(p)
        if s:
            s["story"] = p
            return s
    return None


# ---- families -------------------------------------------------------------------------------------------------------
INTRO = rf"(?:{NAME} has|There (?:are|is|were)|A (?:jar|bag|box|basket) has|(?:\d+) (?P<n2>[a-z]+) are (?:in|on))"


def _start(p):
    """'<Name> has A obj' | 'There are A obj (in a box)' | 'A obj are in a bag' -> (A, noun, rest)."""
    m = re.match(rf"^{NAME} (?:has|had|sees|picks) (\d+) ([a-z]+) and (?:then )?(.*)$", p)   # 'Ben has 2 hats and gets 3 more'
    if m:
        rest = m.group(3)
        if re.match(r"\d+ more", rest): rest = "They gets " + rest              # 'sees 3 balls and then 6 more balls'
        else: rest = SUBJ_FILL + rest
        return int(m.group(1)), m.group(2), rest
    m = re.match(rf"^(?:{NAME} (?:has|had)|There (?:are|is|were)|A (?:jar|bag|box|basket) has) (\d+) ([a-z]+)\b[^.]*\.\s*(?:Then )?(.*)$", p)
    if m: return int(m.group(1)), m.group(2), m.group(3)
    m = re.match(r"^(\d+) ([a-z]+) (?:are|is) (?:in|on) [^.]*\.\s*(.*)$", p)
    if m: return int(m.group(1)), m.group(2), m.group(3)
    return None


SUBJ_FILL = "They "
GAIN = r"(?:gets|got|finds|found|buys|bought|picks|picked|makes|bakes|is given|puts in|adds|catches|grows)"
LOSS = r"(?:gives away|gave away|gives|gave|eats|ate|loses|lost|takes out|took out|takes|took|uses|used|sells|drops|pops)"
ASK_TOTAL = r"(?:How many|Which equation|What is|Write|Should you)"


def f_add(p):
    s = _start(p)
    if not s: return None
    a, noun, rest = s
    m = re.match(rf"^(?:{SUBJ} {GAIN} (\d+)(?: more)?(?: [a-z]+)?|(\d+) more (?:[a-z]+ )?(?:come|join|land|hop|swim|fly in|arrive|are added|is added|are put|is put)[a-z]*(?: [^.]*)?)\.\s*(?:Count on\.\s*)?(.*)$", rest)
    if not m: return None
    b = int(m.group(1) or m.group(2)); q = m.group(3)
    if not re.match(ASK_TOTAL, q) or re.search(r"\bleft\b|Should you", q) or not obj(noun) or not ok(a, b): return None
    return {"kind": "add", "obj": obj(noun), "noun": noun, "a": a, "b": b, "result": a + b}


def f_take(p):
    s = _start(p)
    if not s: return None
    a, noun, rest = s
    m = re.match(rf"^(?:{SUBJ} {LOSS}(?: away)? (\d+)(?: [a-z]+)?(?: to [^.]*)?|(\d+) (?:fly|run|roll|swim|hop|walk) away|(\d+) of them (?:are|is) taken away)\.\s*(?:Count back\.\s*)?(.*)$", rest)
    if not m: return None
    b = int(m.group(1) or m.group(2) or m.group(3)); q = m.group(4)
    if not re.match(ASK_TOTAL, q) or not obj(noun) or b > a or not ok(a): return None
    return {"kind": "take", "obj": obj(noun), "noun": noun, "a": a, "b": b, "result": a - b}


def f_two_colors(p):
    m = re.match(rf"^{NAME} has (\d+) ({COLORS}) ([a-z]+) and (\d+) ({COLORS}) ([a-z]+)\.\s*(.*)$", p)
    if not m or m.group(3) != m.group(6): return None
    a, b, q = int(m.group(1)), int(m.group(4)), m.group(7)
    if not re.match(r"How many [a-z]+ (?:does|in all|are there)|Which equation", q) or not obj(m.group(3)) or not ok(a, b): return None
    return {"kind": "colors", "obj": obj(m.group(3)), "noun": m.group(3), "parts": [[a, m.group(2)], [b, m.group(5)]], "result": a + b}


def f_three_colors(p):
    m = re.match(rf"^{NAME} has (\d+) ([a-z]+)\. (\d+) (?:are )?({COLORS}), (\d+) (?:are )?({COLORS}), and the rest are ({COLORS})\.\s*(.*)$", p)
    if not m: return None
    n, a, b = int(m.group(1)), int(m.group(3)), int(m.group(5))
    if not obj(m.group(2)) or a + b > n or not ok(n): return None
    return {"kind": "colors_rest", "obj": obj(m.group(2)), "noun": m.group(2), "total": n,
            "parts": [[a, m.group(4)], [b, m.group(6)]], "rest_color": m.group(7), "result": n - a - b}


def f_hidden(p):
    m = re.match(r"^There are (\d+) ([a-z]+)\. Some are under a cup\. (?:You|[A-Z][a-z]+) can see (\d+)\.\s*(.*)$", p)
    if not m: return None
    n, a = int(m.group(1)), int(m.group(3))
    if not obj(m.group(2)) or a > n or not ok(n): return None
    return {"kind": "hidden", "obj": obj(m.group(2)), "noun": m.group(2), "total": n, "seen": a, "result": n - a}


def f_fill(p):
    m = re.match(rf"^{NAME} has (\d+) ([a-z]+)\. {SUBJ} (?:wants|needs) (\d+)\.\s*(.*)$", p) or \
        re.match(r"^A (?:box|jar|bag|basket|tray) holds (\d+) ([a-z]+)\. There are (\d+) in the [a-z]+\.\s*(.*)$", p)
    if not m: return None
    if p.startswith("A "): t, noun, a = int(m.group(1)), m.group(2), int(m.group(3))
    else: a, noun, t = int(m.group(1)), m.group(2), int(m.group(3))
    if not obj(noun) or a > t or not ok(t): return None
    return {"kind": "fill", "obj": obj(noun), "noun": noun, "a": a, "target": t, "result": t - a}


def f_change_unknown(p):
    m = re.match(rf"^(?:{NAME} has|There (?:are|were)) (\d+) ([a-z]+)(?: [a-z]+ (?:a|the) [a-z]+)?\. (?:{SUBJ} gets some more(?: and now has| ?\. Now {SUBJ} has) (\d+)|Some more were put [^.]*\. Now there are (\d+))\.\s*(.*)$", p)
    if not m: return None
    a, noun, c = int(m.group(1)), m.group(2), int(m.group(3) or m.group(4))
    if not obj(noun) or c < a or not ok(c): return None
    return {"kind": "fill", "obj": obj(noun), "noun": noun, "a": a, "target": c, "result": c - a}


def f_start_some_taken(p):
    m = re.match(r"^There were (\d+) ([a-z]+) (?:in|on) [^.]*\. Some were (?:taken out|taken away|eaten)\. Now there are (\d+)\.\s*(.*)$", p)
    if not m: return None
    a, noun, c = int(m.group(1)), m.group(2), int(m.group(3))
    if not obj(noun) or c > a or not ok(a): return None
    return {"kind": "group", "obj": obj(noun), "noun": noun, "a": a, "result": a - c}


def f_compare(p):
    m = re.match(rf"^({NAME}) has (\d+) ([a-z]+)\. ({NAME}) has (\d+) ([a-z]+)\.\s*(.*)$", p)
    if not m or m.group(3) != m.group(6): return None
    a, b, q = int(m.group(2)), int(m.group(5)), m.group(7)
    if not re.match(r"How many (?:more|fewer)|Which equation finds how many more|Who has (?:more|fewer)", q): return None
    if not obj(m.group(3)) or not ok(a) or not ok(b): return None
    numeric = q.startswith(("How many", "Which equation"))
    return {"kind": "compare", "obj": obj(m.group(3)), "noun": m.group(3), "rows": [[m.group(1), a], [m.group(4), b]],
            "result": abs(a - b) if numeric else None}


def f_compare_more_fewer(p):
    m = re.match(rf"^({NAME}) (?:has|read|picks|picked|made|found) (\d+) ([a-z]+)\. ({NAME}) (?:has|read|picks|picked|made|found) (\d+) (more|fewer) ([a-z]+) than \1\.\s*(.*)$", p)
    if not m or m.group(3) != m.group(7): return None
    a, d = int(m.group(2)), int(m.group(5))
    if not obj(m.group(3)): return None
    b = a + d if m.group(6) == "more" else a - d
    if b < 0 or not ok(a) or not ok(max(a, b)): return None
    return {"kind": "compare_diff", "obj": obj(m.group(3)), "noun": m.group(3), "rows": [[m.group(1), a], [m.group(4), None]],
            "base": a, "diff": d, "dir": m.group(6), "result": b}


def f_pets(p):
    m = re.match(rf"^{NAME} has (\d+) ([a-z]+), (\d+) ([a-z]+), and (\d+) ([a-z]+)\.\s*(.*)$", p)
    if not m: return None
    g = [(int(m.group(i)), m.group(i + 1)) for i in (1, 3, 5)]
    if not all(obj(n) for _, n in g) or not ok(*[c for c, _ in g]): return None
    return {"kind": "mixed", "groups": [[c, obj(n), n] for c, n in g], "result": sum(c for c, _ in g)}


def f_rest_of_total(p):
    """'There are 10 crayons in all. 3 are yellow and the others are red.' / 'Ivy has 16 hats. 10 are green. The rest are yellow.'"""
    m = re.match(rf"^(?:There are (\d+) ([a-z]+) in all|{NAME} has (\d+) ([a-z]+))\. (\d+) are ({COLORS})(?:,| and|\.) (?:The rest|the rest|the others|The others) are ({COLORS})\.\s*(.*)$", p)
    if not m: return None
    n, noun = int(m.group(1) or m.group(3)), m.group(2) or m.group(4)
    a = int(m.group(5))
    if not obj(noun) or a > n or not ok(n) or not m.group(8).startswith("How many"): return None
    return {"kind": "colors_rest", "obj": obj(noun), "noun": noun, "total": n, "parts": [[a, m.group(6)]],
            "rest_color": m.group(7), "result": n - a}


def f_two_colors_bag(p):
    m = re.match(rf"^There are (\d+) ({COLORS}) ([a-z]+) and (\d+) ({COLORS}) ([a-z]+)(?: in [^.]*)?\.\s*(How many.*)$", p)
    if not m or m.group(3) != m.group(6) or not obj(m.group(3)): return None
    a, b = int(m.group(1)), int(m.group(4))
    if not ok(a, b): return None
    return {"kind": "colors", "obj": obj(m.group(3)), "noun": m.group(3), "parts": [[a, m.group(2)], [b, m.group(5)]], "result": a + b}


def f_compare_colored(p):
    m = re.match(rf"^({NAME}) has (\d+) ({COLORS}) ([a-z]+) and (\d+) ({COLORS}) ([a-z]+)\. ({NAME}) has (\d+)(?: [a-z]+)?\.\s*(How many more does .*)$", p)
    if not m or m.group(4) != m.group(7) or not obj(m.group(4)): return None
    a, b, c = int(m.group(2)), int(m.group(5)), int(m.group(9))
    if c > a + b or not ok(a, b) or not ok(c): return None
    return {"kind": "compare", "obj": obj(m.group(4)), "noun": m.group(4),
            "rows": [[m.group(1), a + b, [[a, m.group(3)], [b, m.group(6)]]], [m.group(8), c]], "result": a + b - c}


def f_cup_box(p):
    m = re.match(rf"^{NAME} has (\d+) ([a-z]+)\. (\d+) (?:are|is) in a cup\. The rest are in a box\.\s*(.*)$", p)
    if not m or not obj(m.group(2)): return None
    n, a = int(m.group(1)), int(m.group(3))
    if a > n or not ok(n): return None
    return {"kind": "hidden", "obj": obj(m.group(2)), "noun": m.group(2), "total": n, "seen": a, "cover": "box", "result": n - a}


def f_start_unknown(p):
    m = re.match(rf"^{NAME} had some ([a-z]+)\. (?:Then )?{SUBJ} (got|found|picked|bought|gave|lost|ate)(?: away)? (\d+)(?: more)?(?: away)?(?:\.| and has) (?:Now {SUBJ} has )?(\d+)(?: left)?\.\s*(.*)$", p)
    if not m or not obj(m.group(1)): return None
    noun, verb, b, c = m.group(1), m.group(2), int(m.group(3)), int(m.group(4))
    if verb in ("gave", "lost", "ate"):
        if not ok(b + c): return None
        return {"kind": "take", "obj": obj(noun), "noun": noun, "a": b + c, "b": b, "result": b + c, "start_unknown": True}
    if b > c or not ok(c): return None
    return {"kind": "add_start", "obj": obj(noun), "noun": noun, "b": b, "total": c, "result": c - b, "start_unknown": True}


def f_some_left(p):
    m = re.match(rf"^(?:{NAME} had|There were) (\d+) ([a-z]+)(?: (?:in|on) [^.]*)?\. (?:{SUBJ} gave some away|Some (?:flew|ran|swam|rolled|hopped|walked) away)\. Now (?:{SUBJ} has|there are) (\d+)\.\s*(.*)$", p)
    if not m or not obj(m.group(2)): return None
    a, c = int(m.group(1)), int(m.group(3))
    if c > a or not ok(a): return None
    return {"kind": "group", "obj": obj(m.group(2)), "noun": m.group(2), "a": a, "result": a - c}


def f_boxes(p):
    m = re.match(r"^There are (\d+) ([a-z]+) in one (box|bag|jar|basket)(?:,| and) (\d+)(?: [a-z]+)? in (?:another|a second) \3(?:, and (\d+)(?: [a-z]+)? in a third \3)?\.\s*(How many.*)$", p)
    if not m or not obj(m.group(2)): return None
    g = [int(m.group(1)), int(m.group(4))] + ([int(m.group(5))] if m.group(5) else [])
    if not ok(*g): return None
    return {"kind": "mixed", "groups": [[c, obj(m.group(2)), m.group(2)] for c in g], "result": sum(g), "boxed": True}


def f_days(p):
    m = re.match(rf"^{NAME} (?:picks|finds|reads|sees|makes) (\d+) ([a-z]+) on [A-Z][a-z]+, (\d+) on [A-Z][a-z]+, and (\d+) on [A-Z][a-z]+\.\s*(How many.*)$", p)
    if not m or not obj(m.group(2)): return None
    g = [int(m.group(1)), int(m.group(3)), int(m.group(4))]
    if not ok(*g): return None
    return {"kind": "mixed", "groups": [[c, obj(m.group(2)), m.group(2)] for c in g], "result": sum(g), "boxed": True}
