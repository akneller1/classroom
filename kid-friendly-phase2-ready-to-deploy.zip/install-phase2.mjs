/** Install Claude's reviewed Phase 2 into two *existing* local GitHub checkouts.
 *  node install-phase2.mjs /path/to/FinancialAlgebra /path/to/classroom
 *  No git writes, commits or pushes. All input is from this handoff directory.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const pkg=path.dirname(fileURLToPath(import.meta.url));
const [faArg, classroomArg]=process.argv.slice(2);
if(!faArg||!classroomArg){console.error('Usage: node install-phase2.mjs <FinancialAlgebra checkout> <classroom checkout>');process.exit(2);}
const fa=path.resolve(faArg), classroom=path.resolve(classroomArg);
const must=(ok,msg)=>{if(!ok)throw Error(msg);};
const read=(p)=>fs.readFileSync(p,'utf8');
const json=(p)=>JSON.parse(read(p));
const hash=(b)=>crypto.createHash('sha256').update(b).digest('hex');
const write=(p,s)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,s);};
const replaceOnce=(s,old,replacement,what)=>{
 if(s.includes(replacement))return s;
 const first=s.indexOf(old);must(first>=0,`Cannot find ${what}: source changed; stopped to avoid breaking current changes`);
 must(s.indexOf(old,first+1)<0,`Ambiguous ${what}: multiple anchors`);
 return s.slice(0,first)+replacement+s.slice(first+old.length);
};
// ----- Preflight every source question and every binary before any changes. -----
const plans=[], bankMap=new Map();
for(const name of fs.readdirSync(path.join(pkg,'patches/math1')).filter(x=>x.endsWith('.json')).sort()){
 const patch=json(path.join(pkg,'patches/math1',name));
 for(const e of patch.edits){
  const dest=path.join(fa,e.bank);
  if(!bankMap.has(dest))bankMap.set(dest,json(dest));
  const q=bankMap.get(dest).questions.find(q=>q.id===e.id);
  must(!!q,`Missing question ${e.id} in ${e.bank}; not applying an outdated patch`);
  const src=e.changes.diagram.to.spec.src;
  must(src.startsWith('question-banks/assets/math1/')&&!src.includes('..'),`Unsafe picture path ${src}`);
  const asset=path.join(pkg,'assets',src),target=path.join(fa,src);
  must(fs.existsSync(asset),`Missing handoff image ${asset}`);
  const present=!!q.diagram;
  if(present)must(q.diagram.spec?.src===src && q.diagram.spec?.alt===e.changes.diagram.to.spec.alt,`Existing diagram differs: ${e.id}`);
  if(fs.existsSync(target))must(hash(fs.readFileSync(target))===hash(fs.readFileSync(asset)),`Existing image differs: ${target}`);
  plans.push({q,e,asset,target,present});
 }
}
must(plans.length===412&&bankMap.size===6,`Expected 412 pictures/6 banks, found ${plans.length}/${bankMap.size}`);
must(new Set(plans.map(x=>x.e.id)).size===412,'Repeated question ID in Phase 2 package');
// ----- Prepare Classroom source edits in memory before changing disk. -----
const cssFile=path.join(classroom,'worksheet-generator/core/elementary/elementary-print.css');
const printFile=path.join(classroom,'worksheet-generator/menu/elementary-print.js');
const browserTestFile=path.join(classroom,'scripts/test-elementary-print-browser.cjs');
let css=read(cssFile), js=read(printFile), browserTest=read(browserTestFile);
const prior='/* Phase 2: unit mascot goes here */';
if(!js.includes('E.unitBadge=function(cfg)')){
 const anchor='E.header=function(cfg,title,version){';
 must(js.includes(anchor),'Missing elementary header renderer');
 const helpers=`// Original grade mascots and unit artwork from the reviewed Phase 2 handoff.\nE.mascot=function(cfg,cls='el-mascot'){const g=E.grade(cfg),a={1:['grade1-dot','Dot'],2:['grade2-cubie','Cubie'],3:['grade3-hexie','Hexie'],4:['grade4-zoom','Zoom'],5:['grade5-bit','Bit']}[g];return a?'<img class="'+esc(cls)+'" src="'+esc(base+'art/mascots/'+a[0]+'.svg')+'" alt="'+esc('Grade '+g+' mascot '+a[1])+'">':'';};\nE.unitBadge=function(cfg){const g=E.grade(cfg),unit=String(cfg?.unitId||'').replace(/^grade[1-5]-/,'');if(g!==1)return E.mascot(cfg,'el-mascot el-badge');if(!/^[a-z0-9-]+$/.test(unit))return '';return '<img class="el-mascot el-badge" src="'+esc(base+'art/unit-badges/grade1/'+unit+'.svg')+'" alt="" aria-hidden="true">';};\n`;
 js=replaceOnce(js,anchor,helpers+anchor,'mascot helper insertion');
}
const headerRe=/E\.header=function\(cfg,title,version\)\{[^\r\n]*?\};/;
const newHeader=`E.header=function(cfg,title,version){const set=NS.skillSets[cfg.unitId];return '<div class="el-band">'+E.unitBadge(cfg)+'<div class="el-titlewrap"><div class="el-unit">'+esc('GRADE '+E.grade(cfg)+' · '+(NS.isWorksheet(cfg)?'PRACTICE':(set?.unitName||cfg.unitId)))+(version?' · '+esc(version):'')+'</div><h1>'+esc(title)+'</h1></div>'+E.mascot(cfg,'el-mascot el-grade-mascot')+'</div>'+((cfg.subtitle&&!/^(?:Practice worksheet|Unit test ·|Assessment Menu ·)/.test(cfg.subtitle))?'<div class="el-custom-note">'+math(cfg.subtitle)+'</div>':'')+E.name(cfg);};`;
if(!js.includes(newHeader)){
 must(headerRe.test(js),'Cannot identify original E.header function');
 js=js.replace(headerRe,newHeader);
}
if(!js.includes('const sidePicture=')){
 const start=`const f=format(cfg,si,p),g=E.grade(cfg),points=`;
 const replacement=`const f=format(cfg,si,p),g=E.grade(cfg),sidePicture=g>0&&g<3&&p.fig&&NS.figHtml&&!singleBlank(p)&&!p.work?.length&&(f==='short-answer-work'||f==='count-picture'),points=`;
 js=replaceOnce(js,start,replacement,'side-picture predicate');
 js=replaceOnce(js,`if(p.fig&&NS.figHtml)h+='<div class="el-figure">'+NS.figHtml(p.fig)+'</div>';`,`if(p.fig&&NS.figHtml&&!sidePicture)h+='<div class="el-figure">'+NS.figHtml(p.fig)+'</div>';`,'skip picture before side-by-side answer');
 const old=`else if(f!=='plot'&&!singleBlank(p))h+='<div class="el-workrow">'+(p.fig&&/count|how many (?:in all|are there)/i.test(p.prompt)?'':work(cfg))+answer(cfg)+'</div>';`;
 const out=`else if(f!=='plot'&&!singleBlank(p))h+=sidePicture?'<div class="el-figrow"><div class="el-figure">'+NS.figHtml(p.fig)+'</div>'+answer(cfg)+'</div>':'<div class="el-workrow">'+(p.fig&&/count|how many (?:in all|are there)/i.test(p.prompt)?'':work(cfg))+answer(cfg)+'</div>';`;
 js=replaceOnce(js,old,out,'picture/answer placement');
}
css=css.replace(/(\.el-g1 \.el-fig, \.el-g2 \.el-fig \{ max-height: )1\.25in(; \})/,(match,a,b)=>a+'2.1in'+b);
const printCap='.el-paper.el-g1 .el-figure:not(:has(.mk-plot)) img,.el-paper.el-g2 .el-figure:not(:has(.mk-plot)) img{max-height:1.25in!important}';
css=replaceOnce(css,printCap,printCap.replace('1.25in','2.1in'),'primary figure max height');
const cssExtra=`\n/* Phase 2: original grade mascots and unit badge framing. */\n.el-band .el-titlewrap{flex:1;min-width:0}\n.el-band .el-grade-mascot{width:.8in;height:.8in;object-fit:contain;margin-left:auto}\n.el-band .el-badge{object-fit:contain}\n.el-paper.el-g35 .el-band .el-grade-mascot{width:.55in;height:.55in}\n/* Grade 1–2: illustrated story model replaces an empty work grid. */\n.el-paper .el-figrow{display:flex;gap:.14in;align-items:flex-end;justify-content:space-between;margin-top:.06in;break-inside:avoid}\n.el-paper .el-figrow .el-figure{flex:1;min-width:0;margin:0}\n.el-paper .el-figrow .el-figure img,.el-paper .el-figrow .el-figure svg{max-width:100%;width:auto;object-fit:contain}\n.el-paper.el-g1 .el-figrow .el-figure img,.el-paper.el-g2 .el-figrow .el-figure img{max-height:1.8in!important}\n.el-paper .el-figrow .el-answer{flex:none;flex-direction:column;align-items:flex-end;gap:.02in;margin:0}\n`;
if(!css.includes('/* Phase 2: original grade mascots and unit badge framing. */'))css+=cssExtra;
browserTest=browserTest.replaceAll('(grade<3?1.25:1.1)','(grade<3?2.1:1.1)');
// ----- Check all art/ destination paths (54 SVGs) before writing. -----
let artCount=0;const arts=[];
function walk(from,relative=''){
 for(const e of fs.readdirSync(from,{withFileTypes:true})){
  const rel=path.join(relative,e.name),src=path.join(from,e.name);
  if(e.isDirectory())walk(src,rel);else if(e.name.endsWith('.svg')){
   const dest=path.join(classroom,'worksheet-generator/core/elementary/art',rel);
   if(fs.existsSync(dest))must(hash(fs.readFileSync(dest))===hash(fs.readFileSync(src)),`Existing mascot/object art differs: ${dest}`);
   arts.push([src,dest]);artCount++;
  }
 }
}
walk(path.join(pkg,'art'));must(artCount===54,`Expected 54 original art assets, found ${artCount}`);
// ----- Apply preflighted edits. -----
let added=0;
for(const {q,e,asset,target,present} of plans){if(!present){q.diagram=e.changes.diagram.to;added++;}const n=e.changes.sourceNotes?.append;if(n&&!String(q.sourceNotes||'').includes(n))q.sourceNotes=(q.sourceNotes||'')+n;if(!fs.existsSync(target)){fs.mkdirSync(path.dirname(target),{recursive:true});fs.copyFileSync(asset,target);}}
for(const [dest,bank] of bankMap)write(dest,JSON.stringify(bank,null,1)+'\n');
for(const [src,dest] of arts){fs.mkdirSync(path.dirname(dest),{recursive:true});if(!fs.existsSync(dest))fs.copyFileSync(src,dest);}
write(cssFile,css);write(printFile,js);write(browserTestFile,browserTest);
console.log(`Phase 2 applied: ${added} new diagrams; ${plans.length} verified Grade 1 picture records; ${bankMap.size} question banks; ${arts.length} original art files.`);
console.log('Next: commit/push FinancialAlgebra, then run pin-grade1.mjs before committing/pushing classroom.');
