# Kid-Friendly Phase 2 — deployment kit for Mr. K's Classroom

This kit contains the **complete original Phase 2 handoff** plus a non-destructive installer for the two separate repositories:

- `akneller1/FinancialAlgebra`: add 412 exact PNGs to the six Grade 1 banks. No questions, answers, levels or standards are modified. The installer refuses to override unrelated diagrams or existing different PNGs.
- `akneller1/classroom`: add 54 original SVGs (37 objects, 5 grade mascots, 12 Grade 1 unit badges), the illustrated title band, a picture/answer side-by-side layout for primary-grade short-answer items, and a larger 2.1-inch print cap. Other courses and previous Phase 1 fixes are preserved. Grade 1's source SHA in the production workflow must be updated **after** the FA commit, or the pictures will not appear on the public site.

## One command on Windows (GitHub Desktop installed)

1. Extract this ZIP to a folder (do not run scripts inside a ZIP preview).
2. Make sure both repositories are cloned locally and their main branches have no uncommitted changes.
3. Open PowerShell in the extracted folder and run:

   ```powershell
   .\deploy-phase2.ps1 -FinancialAlgebra "C:\path\to\FinancialAlgebra" -Classroom "C:\path\to\classroom" -Publish
   ```

The script fast-forwards each clean `main`, validates all 412 question/image associations, applies the changes, commits and pushes FinancialAlgebra, records its exact new commit in Classroom's deployment workflow, then commits and pushes Classroom. `-Publish` is required for Git pushes; without it, changes are applied and verified locally only.

If GitHub authentication in PowerShell is not configured, use **GitHub Desktop** to push the commits instead. To avoid an incomplete live deployment, finish pushing the FinancialAlgebra commit before committing the Classroom change.

## Manual steps (GitHub Desktop alternative)

```powershell
node .\install-phase2.mjs "C:\path\to\FinancialAlgebra" "C:\path\to\classroom"
node .\verify-phase2.mjs "C:\path\to\FinancialAlgebra" "C:\path\to\classroom"
```

Commit/push `FinancialAlgebra` first in Desktop. Then run:

```powershell
node .\pin-grade1.mjs "C:\path\to\FinancialAlgebra" "C:\path\to\classroom"
```

Commit/push `classroom` in Desktop. Verify the `Deploy site` GitHub Actions job and inspect a Grade 1 worksheet/quiz from a unit such as `word-problems-20`.

## Verification performed while packaging

- 412 unique picture references across six bank patch files: 273 Word Problems Within 20, 59 Add/Subtract Within 10, 31 Add/Subtract Within 20, 24 Equal Sign, 21 Count to 120 and 4 Add/Subtract Within 100.
- All 412 bundled PNGs load and preserve their original alt text.
- 54 original SVGs retain their `<title>` accessibility metadata.
- The installer was applied to a six-bank fixture and passed `verify-phase2.mjs`; a second run changed zero existing diagrams (idempotency check).
- Current Classroom source anchors and Grade 1 workflow pin locations were confirmed on GitHub on November 15, 2026.
- The final deployment still needs GitHub Actions to run after the two pushes. Do not treat local verification as a live-site check.

## Boundaries

This phase implements the story illustrations and print title/answer layout. Grade 2 story pictures and Grade 2–5 unit badges are planned for Phase 3. Mascot artwork is prepared for other games, cards and guides; their broader screens are Phase 4 according to the original handoff.
