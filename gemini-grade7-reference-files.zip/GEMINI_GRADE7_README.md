# Gemini Grade 7 Question Bank — Reference Files

Source repository: https://github.com/akneller1/classroom
Source branch: main
Source commit: f944674556da6e273f925f73eb48797bf7181fd1
Snapshot date: 2026-11-02
Course ID: prealgebra7

This archive contains current reference files from the repository, preserved at their original paths. They are INPUTS for Gemini, not generated Grade 7 question banks.

## Use these files

- data.js — defines Grade 7 units, IDs, names, and course settings.
- course-catalog.js — authoritative Grade 7 skill names and skill ID generation. Grade 7 contains 13 units and 114 listed skills.
- schemas/question-bank.schema.json — JSON schema for question-bank payloads.
- scripts/check-question-bank.cjs — structural validator. To execute it, you also need the full GitHub repository, not only the files in this archive.
- question-banks/manifest.json — existing bank manifest; reference only, do not overwrite.
- question-banks/prealgebra/equations-expressions.json — example Grade 8 question bank.
- question-banks/prealgebra/meta/equations-expressions.tags.json — paired example metadata.

## Instructions for Gemini

1. Generate question-banks/prealgebra7/<unit-id>.json using exact unit and skill IDs from these files.
2. Use schemaVersion 1 and courseId prealgebra7. The internal levels are cp2, cp1, honors (teacher-facing Remedial, Standard, Advanced).
3. Generate original, diverse, mathematically verified content, with answer and solutionSteps for each question.
4. Include metadata following the example Grade 8 tags format.
5. Keep new output separate. Do not overwrite any reference file in this archive.
6. Do not alter question-banks/manifest.json or the live GitHub repository; ChatGPT will integrate delivered question bank files later.
7. Run scripts/check-question-bank.cjs within a checkout of the full repository; structural checks do not replace independent math verification.

## Source file blob SHAs (GitHub)

data.js  01e1fee7dc6f41edc889eefa23e46965d2453d4e
course-catalog.js  a2b2f1f9cc28f498b44553ecf1c9dda06fad9a2c
schemas/question-bank.schema.json  8a788070ea238d9ba853e89ba7d5c6ffcd903a61
scripts/check-question-bank.cjs  3e37fe4c582027aa7a4fd28337c72a228e1c9e15
question-banks/manifest.json  18f60c2e6b2fbc1fc9b2320aa79c3d3a3d263857
question-banks/prealgebra/equations-expressions.json  5822c93365fa99368b43a10b7cc3f2d78a540d0a
question-banks/prealgebra/meta/equations-expressions.tags.json  f8a0ba1b072ae3dab49fdb2f165f47e5de7fa8a7
